#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static int looks_hex(const char *s) {
    for (const char *p = s; *p; ++p)
        if ((*p >= 'a' && *p <= 'f') || (*p >= 'A' && *p <= 'F') || *p=='x' || *p=='X')
            return 1;
    return 0;
}
static int looks_octal(const char *s) {
    if (*s == '\0') return 0;
    for (const char *p = s; *p; ++p)
        if (*p < '0' || *p > '7') return 0;
    return 1;
}

int main(void) {
    char buf[128];

    /* stdin yoksa varsayılan 437 */
    if (scanf("%127s", buf) != 1) strcpy(buf, "437");

    unsigned long val;
    if (looks_hex(buf) && !looks_octal(buf)) {
        val = strtoul(buf, NULL, 16);      /* %x yorumu */
    } else if (looks_octal(buf)) {
        val = strtoul(buf, NULL, 8);       /* %o yorumu */
    } else {
        val = strtoul(buf, NULL, 16);      /* 8-9 varsa hex kabul et */
    }

    /* Tek satırda: d u o d x */
    printf("%lu %lu %lo %lu %lx\n", val, val, val, val, val);
    return 0;
}