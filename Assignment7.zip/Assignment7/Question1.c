#include <stdio.h>

int main(void) {
    double num = 100.453627;

    /* floor/round KULLANMADAN yuvarlama: yalnızca +0.5 ve kesme */
    long nearest        = (long)(num + 0.5);
    double tenth        = (long)(num * 10    + 0.5) / 10.0;
    double hundredth    = (long)(num * 100   + 0.5) / 100.0;
    double thousandth   = (long)(num * 1000  + 0.5) / 1000.0;
    double ten_thousand = (long)(num * 10000 + 0.5) / 10000.0;

    printf("%ld\n", nearest);
    printf("%.1f\n",  tenth);
    printf("%.2f\n",  hundredth);
    printf("%.3f\n",  thousandth);
    printf("%.4f\n",  ten_thousand);

    return 0;
}
